import { useState, useEffect } from 'react';
import { Play, Square, CheckCircle, Database } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface ScraperViewProps {
  onCoursesScraped: (courses: Course[]) => void;
}

interface Course {
  id: string;
  code: string;
  description: string;
  schedule: string;
  room: string;
  enrolled: string;
  teacher: string;
  department: string;
}

export function ScraperView({ onCoursesScraped }: ScraperViewProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTask, setCurrentTask] = useState('');
  const [logs, setLogs] = useState<string[]>([]);

  const mockCourses: Course[] = [
    {
      id: '1',
      code: 'CIS 2106 - Group 1',
      description: 'Event Driven Programming',
      schedule: 'MWF 7:30-8:30',
      room: 'RM 304',
      enrolled: '35/40',
      teacher: 'Prof. Santos',
      department: 'CIS'
    },
    {
      id: '2',
      code: 'CIS 2106 - Group 2',
      description: 'Event Driven Programming',
      schedule: 'TTh 9:00-10:30',
      room: 'RM 305',
      enrolled: '38/40',
      teacher: 'Prof. Cruz',
      department: 'CIS'
    },
    {
      id: '3',
      code: 'CS 4206 - Group 1',
      description: 'Machine Learning',
      schedule: 'MWF 10:00-11:00',
      room: 'RM 401',
      enrolled: '30/35',
      teacher: 'Prof. Reyes',
      department: 'CS'
    },
    {
      id: '4',
      code: 'GE-STS - Group 1',
      description: 'Science, Technology & Society',
      schedule: 'TTh 13:00-14:30',
      room: 'RM 201',
      enrolled: '45/50',
      teacher: 'Prof. Garcia',
      department: 'GE'
    },
    {
      id: '5',
      code: 'CIS 2203 - Group 1',
      description: 'Information Management',
      schedule: 'MWF 14:00-15:00',
      room: 'RM 303',
      enrolled: '32/40',
      teacher: 'Prof. Tan',
      department: 'CIS'
    },
    {
      id: '6',
      code: 'CS 4206 - Group 2',
      description: 'Machine Learning',
      schedule: 'TTh 15:00-16:30',
      room: 'RM 402',
      enrolled: '28/35',
      teacher: 'Prof. Villar',
      department: 'CS'
    }
  ];

  const simulateScraping = () => {
    setIsRunning(true);
    setProgress(0);
    setLogs([]);

    const tasks = [
      'Initializing browser...',
      'Logging into USC ISMIS...',
      'Navigating to course schedule...',
      'Setting academic period filters...',
      'Scraping CIS 2106...',
      'Scraping CS 4206...',
      'Scraping GE-STS...',
      'Scraping CIS 2203...',
      'Processing course data...',
      'Scraping complete!'
    ];

    let currentProgress = 0;
    const interval = setInterval(() => {
      if (currentProgress < tasks.length) {
        setCurrentTask(tasks[currentProgress]);
        setLogs(prev => [...prev, `✓ ${tasks[currentProgress]}`]);
        currentProgress++;
        setProgress((currentProgress / tasks.length) * 100);
      } else {
        clearInterval(interval);
        setIsRunning(false);
        onCoursesScraped(mockCourses);
      }
    }, 800);
  };

  const renderProgressBar = (percent: number) => {
    const totalBlocks = 30;
    const filledBlocks = Math.floor((percent / 100) * totalBlocks);
    const emptyBlocks = totalBlocks - filledBlocks;
    
    return (
      <div className="font-mono text-sm">
        <span className="text-[var(--usc-green)]">{'█'.repeat(filledBlocks)}</span>
        <span className="text-gray-300">{'-'.repeat(emptyBlocks)}</span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-semibold">Course Scraper</h1>
        <p className="text-muted-foreground mt-1">Scrape course data from USC ISMIS</p>
      </div>

      {/* Control Card */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold">Scraping Controls</h3>
            <p className="text-sm text-muted-foreground">Start or stop the scraping process</p>
          </div>
          <Button
            onClick={simulateScraping}
            disabled={isRunning}
            className="gap-2"
            style={{ 
              backgroundColor: isRunning ? '#6b7280' : 'var(--usc-green)',
              color: 'white'
            }}
          >
            {isRunning ? (
              <>
                <Square className="w-4 h-4" />
                Running...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Start Scraping
              </>
            )}
          </Button>
        </div>

        {/* Progress Section */}
        {(isRunning || progress > 0) && (
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Progress</span>
                <span className="text-sm font-semibold text-[var(--usc-green)]">
                  {Math.round(progress)}%
                </span>
              </div>
              {renderProgressBar(progress)}
            </div>

            {currentTask && (
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 rounded-full bg-[var(--usc-green)] animate-pulse" />
                {currentTask}
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Logs Card */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Scraping Logs</h3>
        <div className="bg-muted rounded-lg p-4 h-64 overflow-y-auto font-mono text-sm space-y-1">
          {logs.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No logs yet. Start scraping to see activity.</p>
          ) : (
            logs.map((log, index) => (
              <div key={index} className="flex items-start gap-2">
                <span className="text-green-600">✓</span>
                <span>{log.replace('✓ ', '')}</span>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Stats */}
      {progress === 100 && (
        <div className="grid grid-cols-3 gap-4">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold">{mockCourses.length}</p>
                <p className="text-sm text-muted-foreground">Sections Found</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <Database className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold">4</p>
                <p className="text-sm text-muted-foreground">Unique Courses</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold">100%</p>
                <p className="text-sm text-muted-foreground">Success Rate</p>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}