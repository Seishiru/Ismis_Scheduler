import { useState } from 'react';
import { Card } from './ui/card';
import { AlertTriangle, X, Clock } from 'lucide-react';
import { Button } from './ui/button';

interface Course {
  id: string;
  code: string;
  description: string;
  schedule: string;
  room: string;
  enrolled: string;
  teacher: string;
  department: string;
}

interface ScheduledCourse extends Course {
  scheduledId: string;
  day: string;
  startTime: number;
  endTime: number;
}

interface ScheduleBuilderProps {
  draggedCourse: Course | null;
}

export function ScheduleBuilder({ draggedCourse }: ScheduleBuilderProps) {
  const [scheduledCourses, setScheduledCourses] = useState<ScheduledCourse[]>([]);
  const [conflicts, setConflicts] = useState<Set<string>>(new Set());

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const hours = Array.from({ length: 14 }, (_, i) => i + 7); // 7 AM to 8 PM

  const parseDayTime = (schedule: string): { days: string[], startTime: number, endTime: number } | null => {
    // Parse formats like "MWF 7:30-8:30" or "TTh 9:00-10:30"
    const match = schedule.match(/([MTWThFSa]+)\s+(\d+):(\d+)-(\d+):(\d+)/);
    if (!match) return null;

    const dayMap: { [key: string]: string } = {
      'M': 'Monday',
      'T': 'Tuesday',
      'W': 'Wednesday',
      'Th': 'Thursday',
      'F': 'Friday',
      'S': 'Saturday',
      'Sa': 'Saturday'
    };

    const dayString = match[1];
    const days: string[] = [];
    
    // Parse day string
    let i = 0;
    while (i < dayString.length) {
      if (i < dayString.length - 1 && dayString.substring(i, i + 2) === 'Th') {
        days.push('Thursday');
        i += 2;
      } else if (i < dayString.length - 1 && dayString.substring(i, i + 2) === 'Sa') {
        days.push('Saturday');
        i += 2;
      } else {
        const char = dayString[i];
        if (dayMap[char]) {
          days.push(dayMap[char]);
        }
        i++;
      }
    }

    const startHour = parseInt(match[2]);
    const startMin = parseInt(match[3]);
    const endHour = parseInt(match[4]);
    const endMin = parseInt(match[5]);

    return {
      days,
      startTime: startHour + startMin / 60,
      endTime: endHour + endMin / 60
    };
  };

  const checkConflicts = (newCourses: ScheduledCourse[]) => {
    const conflictIds = new Set<string>();

    for (let i = 0; i < newCourses.length; i++) {
      for (let j = i + 1; j < newCourses.length; j++) {
        const course1 = newCourses[i];
        const course2 = newCourses[j];

        if (course1.day === course2.day) {
          const hasOverlap = 
            (course1.startTime < course2.endTime && course1.endTime > course2.startTime);
          
          if (hasOverlap) {
            conflictIds.add(course1.scheduledId);
            conflictIds.add(course2.scheduledId);
          }
        }
      }
    }

    setConflicts(conflictIds);
  };

  const handleDrop = (day: string, hour: number) => {
    if (!draggedCourse) return;

    const parsed = parseDayTime(draggedCourse.schedule);
    if (!parsed) return;

    const newCourses: ScheduledCourse[] = [];
    
    parsed.days.forEach((courseDay) => {
      const scheduledId = `${draggedCourse.id}-${courseDay}-${Date.now()}`;
      newCourses.push({
        ...draggedCourse,
        scheduledId,
        day: courseDay,
        startTime: parsed.startTime,
        endTime: parsed.endTime
      });
    });

    const updatedCourses = [...scheduledCourses, ...newCourses];
    setScheduledCourses(updatedCourses);
    checkConflicts(updatedCourses);
  };

  const handleRemove = (scheduledId: string) => {
    const course = scheduledCourses.find(c => c.scheduledId === scheduledId);
    if (!course) return;

    // Remove all instances of this course (all days)
    const baseId = scheduledId.split('-').slice(0, -2).join('-');
    const updatedCourses = scheduledCourses.filter(c => !c.scheduledId.startsWith(baseId));
    
    setScheduledCourses(updatedCourses);
    checkConflicts(updatedCourses);
  };

  const getCoursesForSlot = (day: string, hour: number) => {
    return scheduledCourses.filter(course => 
      course.day === day &&
      course.startTime <= hour &&
      course.endTime > hour
    );
  };

  const formatTime = (hour: number) => {
    const h = Math.floor(hour);
    const isPM = h >= 12;
    const displayHour = h > 12 ? h - 12 : h === 0 ? 12 : h;
    return `${displayHour}:00 ${isPM ? 'PM' : 'AM'}`;
  };

  const getCourseHeight = (course: ScheduledCourse) => {
    const duration = course.endTime - course.startTime;
    return `${duration * 64}px`; // 64px per hour (h-16)
  };

  const getCourseTop = (course: ScheduledCourse, hour: number) => {
    const offset = course.startTime - hour;
    return `${offset * 64}px`; // 64px per hour
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Schedule Builder</h1>
          <p className="text-muted-foreground mt-1">Drag courses from the table to build your schedule</p>
        </div>
        {scheduledCourses.length > 0 && (
          <div className="flex items-center gap-2 text-sm">
            <Clock className="w-4 h-4 text-[var(--usc-green)]" />
            <span className="font-medium">{scheduledCourses.length} time slots scheduled</span>
          </div>
        )}
      </div>

      {/* Conflict Alert */}
      {conflicts.size > 0 && (
        <Card className="p-4 border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/20">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5" />
            <div>
              <h4 className="font-semibold text-red-900 dark:text-red-200">Schedule Conflicts Detected</h4>
              <p className="text-sm text-red-700 dark:text-red-300 mt-1">
                {conflicts.size} time slot{conflicts.size > 1 ? 's have' : ' has'} overlapping courses. 
                Review highlighted courses below.
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Calendar Grid */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <div className="min-w-[1200px]">
            {/* Header */}
            <div className="grid grid-cols-8 border-b border-border">
              <div className="p-4 bg-muted border-r border-border">
                <span className="font-semibold text-sm text-muted-foreground">Time</span>
              </div>
              {days.map(day => (
                <div key={day} className="p-4 bg-muted border-r border-border last:border-r-0">
                  <span className="font-semibold text-sm" style={{ color: 'var(--usc-green)' }}>
                    {day}
                  </span>
                </div>
              ))}
            </div>

            {/* Time Slots */}
            <div className="grid grid-cols-8">
              {/* Time Column */}
              <div className="border-r border-border">
                {hours.map(hour => (
                  <div key={hour} className="h-16 p-2 border-b border-border bg-muted">
                    <span className="text-xs text-muted-foreground font-medium">
                      {formatTime(hour)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Day Columns */}
              {days.map(day => (
                <div key={day} className="border-r border-border last:border-r-0">
                  {hours.map(hour => {
                    const coursesInSlot = getCoursesForSlot(day, hour);
                    const isFirstSlot = coursesInSlot.length > 0 && coursesInSlot[0].startTime === hour;

                    return (
                      <div
                        key={`${day}-${hour}`}
                        className="h-16 border-b border-border hover:bg-muted/50 transition-colors relative"
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={() => handleDrop(day, hour)}
                      >
                        {isFirstSlot && coursesInSlot.map(course => {
                          const hasConflict = conflicts.has(course.scheduledId);
                          
                          return (
                            <div
                              key={course.scheduledId}
                              className={`absolute left-1 right-1 rounded-md p-2 shadow-sm border-l-4 ${
                                hasConflict 
                                  ? 'bg-red-100 dark:bg-red-900/30 border-red-500 dark:border-red-400' 
                                  : 'bg-green-50 dark:bg-green-900/20 border-[var(--usc-green)]'
                              }`}
                              style={{
                                height: getCourseHeight(course),
                                top: getCourseTop(course, hour),
                                zIndex: 10
                              }}
                            >
                              <div className="flex items-start justify-between gap-2 h-full">
                                <div className="flex-1 min-w-0">
                                  <p className={`font-semibold text-xs truncate ${
                                    hasConflict ? 'text-red-900 dark:text-red-200' : 'text-[var(--usc-green)]'
                                  }`}>
                                    {course.code.split(' - ')[0]}
                                  </p>
                                  <p className="text-xs text-muted-foreground truncate mt-0.5">
                                    {course.room}
                                  </p>
                                  {hasConflict && (
                                    <div className="flex items-center gap-1 mt-1">
                                      <AlertTriangle className="w-3 h-3 text-red-600 dark:text-red-400" />
                                      <span className="text-xs text-red-700 dark:text-red-300 font-medium">Conflict</span>
                                    </div>
                                  )}
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-5 w-5 p-0 hover:bg-background/50"
                                  onClick={() => handleRemove(course.scheduledId)}
                                >
                                  <X className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Empty State */}
      {scheduledCourses.length === 0 && (
        <Card className="p-12 text-center border-dashed">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Courses Scheduled</h3>
            <p className="text-muted-foreground text-sm">
              Drag and drop courses from the data table below to start building your schedule.
              The system will automatically detect conflicts.
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}